def store_mom_data(user_id, transcript, summary):
    # Simulated DB write
    print(f"Stored MoM for {user_id}")