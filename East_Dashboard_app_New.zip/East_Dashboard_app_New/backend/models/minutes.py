from sqlalchemy import Column, Integer, String, Boolean, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from backend.database import Base

class Minutes(Base):
    __tablename__ = "minutes"

    id = Column(Integer, primary_key=True, index=True)
    meeting_id = Column(Integer, ForeignKey("meetings.id", ondelete="CASCADE"), nullable=False)
    prepared_by = Column(String, nullable=False)  # EmailStr as string
    prepared_on = Column(DateTime, nullable=False)
    minutes_content = Column(Text, nullable=False)  # richText field
    minutes_saved_url = Column(String, nullable=True)
    archive = Column(Boolean, default=False)

    meeting = relationship("Meeting", back_populates="minutes")
