from sqlalchemy import Column, Integer, String, Date, ForeignKey
from backend.database import Base
from sqlalchemy.orm import relationship
from pydantic import BaseModel, validator
from typing import List, Optional
class Meeting(Base):
    __tablename__ = "meetings"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    date = Column(Date, nullable=False)  # ✅ Ensure this line exists
    time = Column(String)
    location = Column(String)
    agendas = Column(String)
    meeting_type = Column(String)
    meeting_org = Column(String)
    attendees= Column(String)
    google_meet_link = Column(String)  # 👈 Add this line
    user_id = Column(Integer, ForeignKey("users.id"))  # if you link with user
    user = relationship("User", back_populates="meetings")
    minutes = relationship("Minutes", back_populates="meeting", cascade="all, delete-orphan")
class MeetingOut(BaseModel):
    id:int
    title: str
    date: str
    time: str
    location: Optional[str]
    agendas: List[str]
    meeting_type: Optional[str]
    meeting_org: Optional[str]
    attendees: List[str]
    google_meet_link: Optional[str]

    @validator("agendas", pre=True)
    def convert_agendas(cls, v):
        if isinstance(v, str):
            # Remove brackets if present and split
            v = v.strip("{}")
            return [item.strip() for item in v.split(",") if item.strip()]
        return v

    @validator("attendees", pre=True)
    def convert_attendees(cls, v):
        if isinstance(v, str):
            v = v.strip("{}")
            return [item.strip() for item in v.split(",") if item.strip()]
        return v

    class Config:
        orm_mode = True