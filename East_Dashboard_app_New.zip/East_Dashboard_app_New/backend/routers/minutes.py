from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from backend.schemas.minutes_schema import MinutesCreate, MinutesOut
import backend.crud.minutes_crud as crud
from backend.database import get_db
router = APIRouter(prefix="/minutes", tags=["Minutes"])

@router.post("/create", response_model=MinutesOut)
def create_minutes(minutes: MinutesCreate, db: Session = Depends(get_db)):
    return crud.create_minutes(db, minutes)

@router.get("/{minutes_id}", response_model=MinutesOut)
def read_minutes(minutes_id: int, db: Session = Depends(get_db)):
    result = crud.get_minutes_by_id(db, minutes_id)
    if not result:
        raise HTTPException(status_code=404, detail="Minutes not found")
    return result

@router.get("/meeting/{meeting_id}", response_model=List[MinutesOut])
def read_minutes_by_meeting(meeting_id: int, db: Session = Depends(get_db)):
    return crud.get_minutes_by_meeting(db, meeting_id)

@router.put("/{minutes_id}", response_model=MinutesOut)
def update_minutes(minutes_id: int, minutes: MinutesCreate, db: Session = Depends(get_db)):
    result = crud.update_minutes(db, minutes_id, minutes)
    if not result:
        raise HTTPException(status_code=404, detail="Minutes not found")
    return result

@router.delete("/{minutes_id}")
def delete_minutes(minutes_id: int, db: Session = Depends(get_db)):
    result = crud.delete_minutes(db, minutes_id)
    if not result:
        raise HTTPException(status_code=404, detail="Minutes not found")
    return {"detail": "Minutes deleted successfully"}
