from fastapi import APIRouter, Depends,HTTPException
from sqlalchemy.orm import Session
from backend.database import get_db
from backend.crud import meeting_crud
from backend.crud import meeting_calendar_event
from backend.schemas import meeting_schema


#router = APIRouter(prefix="/meetings", tags=["Meetings"])
router = APIRouter()

@router.post("/create", response_model=meeting_schema.MeetingOut)
def create(meeting: meeting_schema.MeetingCreate, db: Session = Depends(get_db)):
     # Step 1: Create meeting in the database
    db_meeting = meeting_crud.create_meeting(db, meeting)

    # Step 2: Fetch user's Google credentials (based on your auth strategy)
    creds = meeting_calendar_event.authenticate_user_gmap()
    if not creds:
        raise HTTPException(status_code=401, detail="Google authentication failed.")

    try:
        # Step 3: Create event in Google Calendar
        event = meeting_calendar_event.create_event(creds, meeting)
        db_meeting.google_meet_link = event.get("hangoutLink")  # Save link to DB if needed
        db.commit()  # Commit the update
        return db_meeting
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Google Calendar error: {str(e)}")


@router.get("/", response_model=list[meeting_schema.MeetingOut])
def list_all(db: Session = Depends(get_db)):
    return meeting_crud.get_all_meetings(db)
