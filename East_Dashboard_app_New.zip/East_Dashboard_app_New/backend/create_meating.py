from fastapi import FastAPI, Form, HTTPException
from fastapi.responses import RedirectResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime, timedelta
import os
import pickle
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# FastAPI setup
app = FastAPI()

# OAuth2 credentials
CLIENT_SECRET_FILE = 'F:\Projects\PythonPro\East_Dashboard_app\client_secret.json'  # Path to your OAuth 2.0 credentials file
SCOPES = ['https://www.googleapis.com/auth/calendar']
class MeetingCreate(BaseModel):
    title: str
    date: str  # ISO format string
    agendas: List[str]
    location: str
    attendees: List[str]
    google_meet_link: Optional[str] = None
# OAuth2 Authentication and Token Storage
def authenticate_user_gmap():
    """Authenticate and get the credentials for the user"""
    creds = None
    # Check if we have already saved credentials (from the first login)
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    
    # If no valid credentials, ask the user to log in again
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                CLIENT_SECRET_FILE, SCOPES)
            creds = flow.run_local_server(port=8000)  # Use port 8000 for FastAPI
            
        # Save the credentials for next time
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)

    return creds

# Create Google Calendar Event
def create_event(credentials, meeting):
    """Create a Google Calendar event"""
    service = build('calendar', 'v3', credentials=credentials)
    
    start_time = datetime.fromisoformat(meeting.date)
    end_time = start_time + timedelta(hours=1)
    
    event = {
        'summary': meeting.title,
        'location': meeting.location,
        'description': "\n".join(f"• {agenda}" for agenda in meeting.agendas),
        'start': {'dateTime': start_time.isoformat(), 'timeZone': 'Asia/Kolkata'},
        'end': {'dateTime': end_time.isoformat(), 'timeZone': 'Asia/Kolkata'},
        'attendees': [{'email': email} for email in meeting.attendees],
        'reminders': {'useDefault': True},
    }

    if not meeting.google_meet_link:
        event['conferenceData'] = {
            'createRequest': {
                'requestId': f"meet_{start_time.timestamp()}",
                'conferenceSolutionKey': {'type': 'hangoutsMeet'}
            }
        }
    
    # Create event
    created_event = service.events().insert(
        calendarId='primary',
        body=event,
        conferenceDataVersion=1
    ).execute()

    return created_event