from sqlalchemy.orm import Session
from backend.models.meeting import Meeting
from backend.schemas.meeting_schema import MeetingCreate

def create_meeting(db: Session, meeting: MeetingCreate):
    db_meeting = Meeting(**meeting.dict())
    db.add(db_meeting)
    db.commit()
    db.refresh(db_meeting)
    return db_meeting

def get_all_meetings(db: Session):
    return db.query(Meeting).all()


