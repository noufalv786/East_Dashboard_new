from fastapi import FastAPI, Form, HTTPException
from fastapi.responses import RedirectResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime, timedelta
import os
import pickle
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
import re
# FastAPI setup
app = FastAPI()

# OAuth2 credentials
CLIENT_SECRET_FILE = 'F:\Projects\PythonPro\East_Dashboard_app\client_secret.json'  # Path to your OAuth 2.0 credentials file
SCOPES = ['https://www.googleapis.com/auth/calendar']
class MeetingCreate(BaseModel):
    title: str
    date: str  # ISO format string
    agendas: List[str]
    location: str
    attendees: List[str]
    google_meet_link: Optional[str] = None
# OAuth2 Authentication and Token Storage
def authenticate_user_gmap():
    """Authenticate and get the credentials for the user"""
    creds = None
    # Check if we have already saved credentials (from the first login)
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    
    # If no valid credentials, ask the user to log in again
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                CLIENT_SECRET_FILE, SCOPES)
            creds = flow.run_local_server(port=8000)  # Use port 8000 for FastAPI
            
        # Save the credentials for next time
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)

    return creds
def normalize_time(time_str):
    time_str = time_str.strip().upper()

    # Add space before AM/PM if missing (e.g., "1:00PM" → "1:00 PM")
    time_str = re.sub(r'(?<=\d)(AM|PM)$', r' \1', time_str)

    # Try parsing as 12-hour format with AM/PM (e.g., "1:00 PM")
    try:
        return datetime.strptime(time_str, "%I:%M %p").time()
    except ValueError:
        pass

    # Try parsing hour-only 12-hour format (e.g., "1 PM")
    try:
        return datetime.strptime(time_str, "%I %p").time()
    except ValueError:
        pass

    # Try 24-hour format with minutes (e.g., "13:00")
    try:
        return datetime.strptime(time_str, "%H:%M").time()
    except ValueError:
        pass

    # Try hour-only 24-hour format (e.g., "13")
    try:
        return datetime.strptime(time_str.zfill(2), "%H").time()
    except ValueError:
        raise ValueError(f"Invalid time format: {time_str}")


# Create Google Calendar Event
def create_event(credentials, meeting):
    """Create a Google Calendar event"""
    service = build('calendar', 'v3', credentials=credentials)

    print(f"Meeting Title: {meeting.title}")
    print(f"Raw Time Input: {meeting.time}")

    # Convert date and time to datetime object
    start_time = datetime.combine(meeting.date, normalize_time(meeting.time))
    end_time = start_time + timedelta(hours=1)  # 1-hour duration by default

    # Handle agendas
    agendas = [a.strip() for a in meeting.agendas.split(",")] if isinstance(meeting.agendas, str) else [a.strip() for a in meeting.agendas]

    # Handle attendees
    attendees = [e.strip() for e in meeting.attendees.split(",")] if isinstance(meeting.attendees, str) else [e.strip() for e in meeting.attendees]

    # Build the event payload
    event = {
        'summary': meeting.title,
        'location': meeting.location,
        'description': "\n".join(f"• {agenda}" for agenda in agendas),
        'start': {
            'dateTime': start_time.isoformat(),
            'timeZone': 'Asia/Kolkata',
        },
        'end': {
            'dateTime': end_time.isoformat(),
            'timeZone': 'Asia/Kolkata',
        },
        'attendees': [{'email': email} for email in attendees],
        'reminders': {'useDefault': True},
        'conferenceData': {
            'createRequest': {
                'requestId': f"meet_{start_time.timestamp()}",
                'conferenceSolutionKey': {'type': 'hangoutsMeet'}
            }
        }
    }

    print(f"Google Calendar Event Payload: {event}")

    # Create event in Google Calendar
    created_event = service.events().insert(
        calendarId='primary',
        body=event,
        conferenceDataVersion=1
    ).execute()

    return created_event