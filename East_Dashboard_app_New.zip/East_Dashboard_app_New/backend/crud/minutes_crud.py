from sqlalchemy.orm import Session
from backend.models.minutes import Minutes
from backend.schemas.minutes_schema import MinutesCreate
def create_minutes(db: Session, minutes: MinutesCreate):
    db_minutes = Minutes(**minutes.dict())
    db.add(db_minutes)
    db.commit()
    db.refresh(db_minutes)
    return db_minutes

def get_minutes_by_id(db: Session, minutes_id: int):
    return db.query(Minutes).filter(Minutes.id == minutes_id).first()

def get_minutes_by_meeting(db: Session, meeting_id: int):
    return db.query(Minutes).filter(Minutes.meeting_id == meeting_id).all()

def update_minutes(db: Session, minutes_id: int, updated_data: MinutesCreate):
    db_minutes = db.query(Minutes).filter(Minutes.id == minutes_id).first()
    if not db_minutes:
        return None
    for key, value in updated_data.dict().items():
        setattr(db_minutes, key, value)
    db.commit()
    db.refresh(db_minutes)
    return db_minutes

def delete_minutes(db: Session, minutes_id: int):
    db_minutes = db.query(Minutes).filter(Minutes.id == minutes_id).first()
    if not db_minutes:
        return None
    db.delete(db_minutes)
    db.commit()
    return db_minutes
