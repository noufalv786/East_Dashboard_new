from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
import os
from dotenv import load_dotenv

load_dotenv()  # load environment variables from a .env file

# --- Database URL Format: postgresql://user:password@host:port/database
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:root123@localhost:5432/east_dashboarddb")

# --- Create SQLAlchemy Engine
engine = create_engine(DATABASE_URL)

# --- Create a configured "Session" class
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# --- Base class for models
Base = declarative_base()
# Create all tables defined via Base subclasses
Base.metadata.create_all(bind=engine)
# --- Dependency for FastAPI routes
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
