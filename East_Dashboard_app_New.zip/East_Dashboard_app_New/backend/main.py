from fastapi import FastAPI, Depends, HTTPException,File, UploadFile
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from .auth import authenticate_user, create_access_token, get_current_user, Token, TokenData
from .ml_utils_bkp import process_mom
from .create_meating import MeetingCreate,authenticate_user_gmap,create_event
from datetime import datetime, timedelta
from .routers import meetings,minutes  # Import your routers
app = FastAPI()
# Enable CORS for frontend communication
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Update with your frontend URL in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(meetings.router, prefix="/meetings", tags=["Meetings"])
app.include_router(minutes.router)
@app.post("/token", response_model=Token)
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    user = authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=401,
            detail="Invalid username or password",
        )
    access_token = create_access_token(data={"user_id": form_data.username, "role": user["role"]})
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/protected")
async def read_protected_data(current_user: TokenData = Depends(get_current_user)):
    return {"message": f"Hello {current_user.user_id}, you are logged in as {current_user.role}."}

@app.get("/users/me")
async def read_users_me(current_user: TokenData = Depends(get_current_user)):
    return {"user_id": current_user.user_id, "role": current_user.role}

@app.get("/admin")
async def read_admin_data(current_user: TokenData = Depends(get_current_user)):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Not authorized")
    return {"message": f"Welcome Admin {current_user.user_id}"}


@app.post("/process_mom")
async def process_mom_file(file: UploadFile = File(...), user=Depends(get_current_user)):
   
    content = await file.read()
    summary, transcript, action_items = process_mom(content, file.filename)
    return {
        "summary": summary,
        "transcript": transcript,
        "action_items": action_items
    }

@app.post("/create_meeting")
async def create_meeting_fn(meeting: MeetingCreate):
     # Authenticate the user
    creds = authenticate_user_gmap()
    print(f"Credentials{creds}")
    try:
        event = create_event(creds, meeting)
        return {"message": "Meeting created", "eventLink": event.get("htmlLink")}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    event=create_meeting(meeting)
    return {"message": "Meeting created", "eventLink": event.get("htmlLink")}
    start_time = datetime.fromisoformat(meeting.date)
    end_time = start_time + timedelta(hours=1)

    event = {
        'summary': meeting.title,
        'location': meeting.location,
        'description': "\n".join(f"• {agenda}" for agenda in meeting.agendas),
        'start': {'dateTime': start_time.isoformat(), 'timeZone': 'Asia/Kolkata'},
        'end': {'dateTime': end_time.isoformat(), 'timeZone': 'Asia/Kolkata'},
        'attendees': [{'email': email} for email in meeting.attendees],
        'reminders': {
            'useDefault': True,
        },
    }

    if not meeting.google_meet_link:
        event['conferenceData'] = {
            'createRequest': {
                'requestId': f"meet_{start_time.timestamp()}",
                'conferenceSolutionKey': {'type': 'hangoutsMeet'}
            }
        }

    event = calendar_service.events().insert(
        calendarId='primary',
        body=event,
        conferenceDataVersion=1
    ).execute()

    return {"message": "Meeting created", "eventLink": event.get("htmlLink")}