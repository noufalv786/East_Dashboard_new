import os
import io
import re
import cv2
import numpy as np
from typing import Tuple, List
from PIL import Image
import pytesseract
import whisper
os.environ["TESSDATA_PREFIX"] = r"C:\Program Files\Tesseract-OCR\tessdata"


def process_mom(file_bytes: bytes, filename: str) -> Tuple[str, str, List[str]]:
    filename = filename.strip()
    ext = filename.split(".")[-1].lower()

    transcript = ""

    # Step 1: Transcription or OCR
    if ext in ["mp3", "wav", "m4a"]:
        model = whisper.load_model("tiny")  # simpler model
        temp_file = f"temp_audio.{ext}"
        with open(temp_file, "wb") as f:
            f.write(file_bytes)
        result = model.transcribe(temp_file)
        transcript = result.get("text", "")
        os.remove(temp_file)

    elif ext == "txt":
        transcript = file_bytes.decode("utf-8", errors="ignore")

    elif ext in ["png", "jpg", "jpeg"]:
       # image = Image.open(io.BytesIO(file_bytes))
        image = Image.open(filename)
        image = np.array(image)
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Apply thresholding
        _, thresh = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)
        # Save and OCR
        processed_image = Image.fromarray(thresh)
        transcript = pytesseract.image_to_string(processed_image, lang="mal",config='--psm 6')

    else:
        raise ValueError(f"Unsupported file type: {ext}")

    if not transcript.strip():
        raise ValueError("Transcript is empty. Make sure the file has readable content.")

    # Step 2: Basic Summarization (Optional: Remove for speed)
    try:
        from transformers import pipeline
        summarizer = pipeline("summarization", model="sshleifer/distilbart-cnn-12-6")
        chunks = [transcript[i:i+1000] for i in range(0, len(transcript), 1000)]
        summary_parts = []
        for chunk in chunks:
            result = summarizer(chunk)
            if result and 'summary_text' in result[0]:
                summary_parts.append(result[0]['summary_text'])
        summary = " ".join(summary_parts)
    except:
        summary = transcript[:300] + "..."  # fallback to first 300 chars

    # Step 3: Extract action items
    action_items = re.findall(r'Action Item:(.*?)\n', transcript, re.IGNORECASE)

    return summary.strip(), transcript.strip(), action_items
