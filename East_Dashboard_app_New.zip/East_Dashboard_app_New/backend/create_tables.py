
from backend.database import Base, engine
from backend.models.meeting import Meeting  # ensure this imports your model
from backend.models.user import User       # assuming you have a User model

Base.metadata.create_all(bind=engine)
print("Tables created successfully.")