import os
import io
import re
from typing import Tuple, List
from google.cloud import vision
import cv2
import numpy as np
from PIL import Image
import whisper

# Set environment variable for Google Cloud credentials
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = r"F:\Projects\PythonPro\East_Dashboard_app\mom-rsc-3eb56731d3ce.json"

def preprocess_image(image_bytes: bytes) -> np.ndarray:
    """Preprocess image before passing to OCR"""
    # Open image
    image = Image.open(io.BytesIO(image_bytes))
    image = np.array(image)

    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Apply thresholding (binarization) to make text stand out
    _, thresh = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)

    # Resize image for better OCR accuracy
    resized = cv2.resize(thresh, (600, 600))  # Resizing might help with text extraction

    return resized

def extract_text_google_ocr(file_bytes: bytes) -> str:
    """Extract text from image using Google Cloud Vision OCR"""
    # Preprocess the image
    processed_image = preprocess_image(file_bytes)

    # Convert to bytes again after preprocessing
    _, buffer = cv2.imencode('.png', processed_image)
    processed_image_bytes = io.BytesIO(buffer)

    # Initialize Vision API client
    client = vision.ImageAnnotatorClient()
    image = vision.Image(content=processed_image_bytes.getvalue())

    # Request text detection
    response = client.text_detection(image=image)

    if response.error.message:
        raise Exception(f"Google Vision API error: {response.error.message}")

    # Debugging: Print OCR Response
    print(f"OCR Response: {response.full_text_annotation.text}")

    return response.full_text_annotation.text if response.full_text_annotation.text else ""

def process_mom(file_bytes: bytes, filename: str) -> Tuple[str, str, List[str]]:
    filename = filename.strip()
    ext = filename.split(".")[-1].lower()

    print(f"Processing file: {filename}, Extension: {ext}")  # Debugging
    transcript = ""

    # Step 1: Transcription or OCR
    if ext in ["mp3", "wav", "m4a"]:
        model = whisper.load_model("tiny")
        temp_file = f"temp_audio.{ext}"
        with open(temp_file, "wb") as f:
            f.write(file_bytes)
        result = model.transcribe(temp_file)
        transcript = result.get("text", "")
        os.remove(temp_file)
        print(f"Audio Transcription Result: {transcript}")  # Debugging

    elif ext == "txt":
        try:
            transcript = file_bytes.decode("utf-8")
        except UnicodeDecodeError:
            raise ValueError("Failed to decode .txt file. Please ensure the file is a valid UTF-8 text file.")
        print(f"Text File Content: {transcript}")  # Debugging

    elif ext in ["png", "jpg", "jpeg"]:
        # Use Google Cloud Vision OCR for image
        transcript = extract_text_google_ocr(file_bytes)
        print(f"OCR Result: {transcript}")  # Debugging

    else:
        raise ValueError(f"Unsupported file type: {ext}")

    if not transcript.strip():
        raise ValueError("Transcript is empty. Make sure the file has readable content.")

    # Step 2: Basic Summarization
    try:
        from transformers import pipeline
        summarizer = pipeline("summarization", model="sshleifer/distilbart-cnn-12-6")
        chunks = [transcript[i:i+1000] for i in range(0, len(transcript), 1000)]
        summary_parts = []
        for chunk in chunks:
            result = summarizer(chunk)
            if result and 'summary_text' in result[0]:
                summary_parts.append(result[0]['summary_text'])
        summary = " ".join(summary_parts)
        print(f"Summary: {summary}")  # Debugging
    except Exception as e:
        summary = transcript[:300] + "..."  # fallback summary
        print(f"Summarization failed: {e}")

    # Step 3: Extract action items
    action_items = re.findall(r'Action Item:(.*?)\n', transcript, re.IGNORECASE)
    print(f"Action Items: {action_items}")  # Debugging

    return summary.strip(), transcript.strip(), action_items
