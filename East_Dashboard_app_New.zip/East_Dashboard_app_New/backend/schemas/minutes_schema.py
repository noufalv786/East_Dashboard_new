from pydantic import BaseModel, EmailStr
from datetime import date, datetime
from typing import List, Optional

class MinutesCreate(BaseModel):
    meeting_id: int
    prepared_by: str
    prepared_on: datetime
    minutes_content: str  # rich text (HTML, Markdown, or plain)
    minutes_saved_url: Optional[str] = None
    archive: Optional[bool] = False

class MinutesOut(MinutesCreate):
    id: int

    class Config:
        from_attributes = True
