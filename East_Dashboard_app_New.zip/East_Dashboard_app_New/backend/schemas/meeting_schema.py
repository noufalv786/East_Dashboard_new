from pydantic import BaseModel, EmailStr
from datetime import date
from typing import List, Optional
from pydantic import validator
class MeetingCreate(BaseModel):
    title: str
    date: date
    time: str
    location: str
    meeting_org: Optional[str] = ""     # defaults to empty string if None or missing
    meeting_type: Optional[str] = ""
    agendas: List[str]
    attendees: List[EmailStr]
    user_id: int

class MeetingOut(MeetingCreate):
    id: int
    google_meet_link: Optional[str] = None

    @validator('agendas', pre=True)
    def parse_agendas(cls, v):
        if isinstance(v, str):
            # remove braces and split by comma
            v = v.strip('{}')
            return [item.strip() for item in v.split(',') if item.strip()]
        return v

    @validator('attendees', pre=True)
    def parse_attendees(cls, v):
        if isinstance(v, str):
            v = v.strip('{}')
            return [item.strip() for item in v.split(',') if item.strip()]
        return v

    class Config:
        from_attributes = True