import streamlit as st
import requests

API_URL = "http://localhost:8000"  # Change to deployed API URL if necessary

# Session defaults
if "token" not in st.session_state:
    st.session_state.token = None
if "username" not in st.session_state:
    st.session_state.username = None
if "role" not in st.session_state:
    st.session_state.role = None
if "menu" not in st.session_state:
    st.session_state.menu = "Dashboard"  # Default to Dashboard after successful login

# Custom CSS for sidebar styling
st.markdown("""
    <style>
    /* Sidebar Styling */
    .sidebar {
        background-color: #3b4c74;
        width: 250px;
        padding: 20px;
        color: white;
        font-family: 'Arial', sans-serif;
        border-radius: 8px;
    }

    .sidebar a {
        display: block;
        padding: 15px;
        text-decoration: none;
        color: #d1d9e6;
        font-size: 18px;
        margin: 10px 0;
        border-radius: 5px;
        transition: 0.3s;
    }

    .sidebar a:hover {
        background-color: #4CAF50;
        color: white;
    }

    .sidebar a.active {
        background-color: #4CAF50;
        color: white;
    }

    .sidebar .logo img {
        width: 200px;
        margin-bottom: 20px;
    }

    /* Main Content Area */

    </style>
""", unsafe_allow_html=True)
st.markdown("""
    <style>
    /* Override default block container width */
  
    /* Main Content Area */
    .main-content {
        padding: 20px;
        background-color: #f4f7fb;
        margin-left: 250px;  /* Ensure that content starts after the sidebar */
        width: 100%;  /* Full width content */
        box-sizing: border-box;  /* Include padding in width calculation */
    }
    </style>
""", unsafe_allow_html=True)
if not st.session_state.token:
        # For login page, full width
        st.markdown("""
            <style>
                .block-container {
                  
                    width: 100% !important;
                    padding: 0 20px;  /* Optional: remove padding for full-width */
                }
            </style>
        """, unsafe_allow_html=True)
else:
    # For dashboard, set a custom width (e.g., 1200px)
    st.markdown("""
        <style>
            .block-container {
               max-width: 100% !important;
                width: 100% !important;
                padding: 0 20px;  /* Optional: adjust padding for dashboard */
            }
        </style>
    """, unsafe_allow_html=True)

# Logout function
def logout():
    st.session_state.token = None
    st.session_state.username = None
    st.session_state.role = None
    st.session_state.menu = "Dashboard"  # Reset to Dashboard after logout
    st.rerun()  # Refresh the app to reinitialize the session state

# Authentication and user fetch
def login(username, password):
 with st.spinner("🔐 Logging in..."):
    res = requests.post(f"{API_URL}/token", data={"username": username, "password": password})
    if res.status_code == 200:
        token = res.json()["access_token"]
        st.session_state.token = token
        user_info = requests.get(f"{API_URL}/users/me", headers={"Authorization": f"Bearer {token}"})
        if user_info.status_code == 200:
            info = user_info.json()
            st.session_state.username = info["user_id"]
            st.session_state.role = info["role"]
        st.success("✅ Login Successful")
        st.session_state.menu = "Dashboard"  # Set menu to Dashboard after successful login
        st.rerun()  # Trigger a rerun to refresh the state and show the correct content
    else:
        st.error("❌ Invalid username or password")

# Sidebar Menu
# Custom CSS for sidebar styling
st.cache_data.clear()


def updateMenu(key):
     st.session_state.menu=key
     st.rerun()
# Sidebar Menu Function
import streamlit as st

# Ensure session state
if "menu" not in st.session_state:
    st.session_state.menu = "Dashboard"

def sidebar():
    with st.sidebar:
        st.markdown("""
            <style>
                .menu-title {
                    font-size: 24px;
                    font-weight: bold;
                    color: #1f77b4;
                    margin-bottom: 20px;
                }
                .stButton > button {
                    width: 100%;
                    text-align: left;
                    background-color: #000000;
                    color: white;
                    padding: 12px 20px;
                    margin: 5px 0;
                    border-radius: 8px;
                    font-size: 16px;
                    transition: background-color 0.3s;
                }
                .stButton > button:hover {
                    background-color: #4CAF50;
                }
            </style>
        """, unsafe_allow_html=True)

        st.markdown('<div class="menu-title">🧠 Smart MoM</div>', unsafe_allow_html=True)

        menu_items = {
            "Dashboard": "📊 Dashboard",
            "Upload MoM": "📁 Upload MoM",
            "Settings": "⚙️ Settings",
            "Logout": "🚪 Logout"
        }

        for key, label in menu_items.items():
            if st.button(label, key=key):
                st.session_state.menu = key
                st.rerun()  # rerun to reflect menu update

# Usage




# Top Bar
def top_bar():
    st.markdown(
        """
        <style>
        .top-bar {
            background-color: #1f4e79;  /* 💡 Change this hex to your desired color */
            padding: 5px 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            width:100%;
            border-radius: 0 0 10px 10px;
        }
        .top-bar h3 {
            margin: 0;
            font-size: 22px;
        }
        .top-bar .user-info {
            font-size: 16px;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    st.markdown(
        f"""
        <div class="top-bar">
            <h3>🧠 AI Minutes of Meeting Dashboard</h3>
            <div class="user-info">👤 {st.session_state.username} ({st.session_state.role})</div>
        </div>
        """,
        unsafe_allow_html=True
    )

# Main Content Display
def display_content():
    if st.session_state.menu == "Dashboard":
        st.subheader("📊 Dashboard Overview")
        st.write("Welcome to the dashboard. Use the sidebar to upload and process MoM.")
    
    elif st.session_state.menu == "Upload MoM":
        st.subheader("📋 Upload Minutes of Meeting")
        uploaded_file = st.file_uploader("Upload audio/image/text", type=["txt", "wav", "mp3", "png", "jpg"], label_visibility="collapsed")
    
        if uploaded_file:
            filename = uploaded_file.name  # Get the file name with extension
            file_bytes = uploaded_file.getvalue()  # Get the file content as bytes

            with st.spinner("Processing..."):
                # Send the file with both content and filename to your API
                res = requests.post(
                    f"{API_URL}/process_mom",
                    files={"file": (filename, file_bytes)},  # Ensure you're sending both file content and filename
                    headers={"Authorization": f"Bearer {st.session_state['token']}"}
                )
       
                if res.status_code == 200:
                    data = res.json()
                    st.success("✅ Processed Successfully!")
                    st.subheader("🗣 Transcript")
                    st.write(data["transcript"])
                    st.subheader("🧠 Summary")
                    st.write(data["summary"])
                    if "action_items" in data:
                        st.subheader("✅ Action Items")
                        st.write(data["action_items"])
                else:
                    st.error(f"Processing failed. Status code: {res.status_code}, Response: {res.text}")
    
    elif st.session_state.menu == "Settings":
        st.subheader("⚙️ Settings")
        st.write("Adjust your preferences here.")
    
    elif st.session_state.menu == "Logout":
        logout()

# Main Logic
if not st.session_state.token:
    st.title("🔐 Admin Login")
    username = st.text_input("Username", max_chars=50, placeholder="Enter your username")
    password = st.text_input("Password", type="password", max_chars=100, placeholder="Enter your password")
    if st.button("Login", use_container_width=True):
        login(username, password)

else:
    top_bar()
    sidebar()  # Sidebar navigation menu
    st.markdown('<div class="main-content">', unsafe_allow_html=True)
    display_content()  # Display content based on menu selection
    st.markdown('</div>', unsafe_allow_html=True)
