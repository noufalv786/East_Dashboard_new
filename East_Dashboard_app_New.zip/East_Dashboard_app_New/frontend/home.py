import streamlit as st

# Page config
st.set_page_config(page_title="Smart MoM", layout="wide")

# Session state defaults
if "token" not in st.session_state:
    st.session_state.token = None
if "username" not in st.session_state:
    st.session_state.username = None
if "role" not in st.session_state:
    st.session_state.role = None
if "menu" not in st.session_state:
    st.session_state.menu = "Dashboard"

# If not logged in
if not st.session_state.token:
    # Hide sidebar
    st.markdown("""
        <style>
        [data-testid="stSidebar"] {
            display: none;
        }
        </style>
    """, unsafe_allow_html=True)

    # Page background and center box styling
    st.markdown("""
        <style>
        .login-box {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0px 4px 25px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .login-title {
            font-size: 28px;
            color: #1f77b4;
            margin-bottom: 30px;
            font-weight: bold;
        }
        .stTextInput > div > input {
            padding: 14px;
            border-radius: 10px;
            border: 1px solid #ccc;
        }
        .stButton > button {
            background-color: #1f77b4;
            color: white;
            padding: 14px;
            border-radius: 10px;
            font-size: 16px;
            width: 100%;
        }
        .stButton > button:hover {
            background-color: #155a8a;
        }
        </style>
    """, unsafe_allow_html=True)

    # Centered layout using columns
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
    
        st.markdown('<div class="login-title">🔐 Admin Login</div>', unsafe_allow_html=True)

        username = st.text_input("Username")
        password = st.text_input("Password", type="password")

        if st.button("Login"):
            from utils.auth import login
            login(username, password)

        st.markdown('</div>', unsafe_allow_html=True)

# If logged in
else:
    # Custom Sidebar
    st.markdown("""
        <style>
        [data-testid="stSidebarNav"] {
            display: none;  /* Hide default nav */
        }
        .custom-sidebar-title {
            font-size: 24px;
            font-weight: bold;
            color: #000;
            padding: 10px;
            margin-bottom: 20px;
        }
        .stButton > button {
            background-color: #2c3e50;
            color: white;
            padding: 10px;
            border-radius: 8px;
            width: 100%;
            text-align: left;
            font-size: 16px;
        }
        .stButton > button:hover {
            background-color: #1abc9c;
            color: white;
        }
        </style>
    """, unsafe_allow_html=True)

with st.sidebar:
        st.title("🧠 Smart MoM")
        st.page_link("home.py", label="📊 Dashboard")
        st.page_link("pages/Create_Meeting.py", label="📁 Create Meeting")
        st.page_link("pages/Meeting_lists.py", label="📁 Meetings")
        st.page_link("pages/Upload_MoM.py", label="📝 Upload MoM")
        st.page_link("pages/Settings.py", label="⚙️ Settings")
        # Main content
        st.success(f"✅ Logged in as {st.session_state.username}")
       # st.markdown('<div class="main-content">', unsafe_allow_html=True)

   
        #st.markdown('</div>', unsafe_allow_html=True)