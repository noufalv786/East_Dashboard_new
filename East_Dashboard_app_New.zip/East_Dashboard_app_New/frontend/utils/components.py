import streamlit as st
from datetime import datetime

def render_top_header():
    # Ensure session keys exist
    if "user" not in st.session_state:
        st.session_state["user"] = "Guest"

    st.markdown(f"""
        <style>
            .top-header {{
                background: linear-gradient(90deg, #f9fafc, #f2f5f8);
                padding: 1rem 2rem;
              /*  margin: -2rem -2rem 0 -2rem;*/
                border-bottom: 1px solid #ddd;
                display: flex;
                justify-content: space-between;
                align-items: center;
                border-radius: 0 0 10px 10px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.03);
            }}
            .header-left {{
                font-weight: 600;
                font-size: 1.1rem;
            }}
            .header-right {{
                display: flex;
                align-items: center;
                gap: 1.2rem;
                font-size: 0.95rem;
            }}
            .notification-icon {{
                font-size: 1.2rem;
                color: #555;
                cursor: pointer;
            }}
            .logout-button {{
                background-color: #ff4d4f;
                color: white;
                padding: 0.4rem 0.8rem;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                font-weight: 500;
            }}
        </style>

        <div class="top-header">
            <div class="header-left">👋 Welcome, <b>{st.session_state["user"]}</b></div>
            <div class="header-right">
                <span class="notification-icon">🔔</span>
                <span>🗓️ {datetime.now().strftime('%A, %B %d, %Y — %I:%M %p')}</span>
                <form action="?logout=true" method="get">
                    <button class="logout-button" name="logout">🚪 Logout</button>
                </form>
            </div>
        </div>
    """, unsafe_allow_html=True)

    # Check for logout from query parameters
    query_params = st.query_params
    if "logout" in st.query_params:
        print(f"loggedout")
        st.session_state.clear()
        st.success("✅ Logged out successfully.")
        st.rerun()  # Refresh the app
        st.stop()
