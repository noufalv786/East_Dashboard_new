# utils/sidebar.py

import streamlit as st

def render_sidebar():
    # --- Safely initialize session keys ---
    for key in ["token", "username", "role"]:
        if key not in st.session_state:
            st.session_state[key] = None

    if not st.session_state.token:
        # Hide sidebar if not logged in
        st.markdown("""
            <style>
                [data-testid="stSidebar"] {
                    display: none;
                }
            </style>
        """, unsafe_allow_html=True)
        return  # 🛑 Stop rendering links if not logged in

    # --- Sidebar styles ---
    st.markdown("""
        <style>
            .custom-sidebar-title {
                font-size: 24px;
                font-weight: bold;
                color: #000;
                padding: 10px;
                margin-bottom: 20px;
            }
            .stButton > button {
                background-color: #2c3e50;
                color: white;
                padding: 10px;
                border-radius: 8px;
                width: 100%;
                text-align: left;
                font-size: 16px;
            }
            .stButton > button:hover {
                background-color: #1abc9c;
            }
        </style>
    """, unsafe_allow_html=True)

    # --- Sidebar content ---
    with st.sidebar:
        st.markdown('<div class="custom-sidebar-title">🧠 Smart MoM</div>', unsafe_allow_html=True)
        st.page_link("home.py", label="📊 Dashboard")
        st.page_link("pages/Create_Meeting.py", label="📁 Create Meeting")
        st.page_link("pages/Meeting_lists.py", label="📝 MOM Meetings")
        st.page_link("pages/Upload_MoM.py", label="📝 Upload MoM")
        st.page_link("pages/Settings.py", label="⚙️ Settings")

        if st.button("🚪 Logout"):
            st.session_state.clear()
            st.success("✅ Logged out. Please refresh.")
            st.stop()
