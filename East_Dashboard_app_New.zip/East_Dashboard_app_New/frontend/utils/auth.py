import requests
import streamlit as st
from streamlit_js_eval import streamlit_js_eval  # Add this

API_URL = "http://localhost:8001"  # adjust as needed

def login(username, password):
    with st.spinner("🔐 Logging in..."):
        try:
            res = requests.post(
                f"{API_URL}/token",
                data={"username": username, "password": password},
                timeout=10
            )
            res.raise_for_status()
            token = res.json().get("access_token")

            # Save token in session and local storage
            st.session_state.token = token
            streamlit_js_eval(js_expressions=f"localStorage.setItem('access_token', '{token}')", key="set_token")

            user_info = requests.get(
                f"{API_URL}/users/me",
                headers={"Authorization": f"Bearer {token}"}
            )
            user_info.raise_for_status()
            info = user_info.json()

            st.session_state.username = info["user_id"]
            st.session_state.role = info["role"]
            st.session_state.is_logged_in = True

            st.success("✅ Login successful")
            st.rerun()
        except Exception as e:
            print(f"Login error: {e}")
            st.error("❌ Invalid username or password")
def require_login():
    print(f"Logged data...{ st.session_state}")
    if not st.session_state.get("token"):
        st.warning("⚠️ You must be logged in to view this page.")
        #st.rerun()
        st.switch_page("home.py")  # Adjust based on your file name
