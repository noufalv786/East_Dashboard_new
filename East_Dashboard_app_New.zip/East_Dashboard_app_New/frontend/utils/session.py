# utils/session.py
import streamlit as st
from streamlit_js_eval import streamlit_js_eval
def init_session():
    defaults = {
        "token": None,
        "username": None,
        "role": None,
        "is_logged_in": False,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value

def restore_token_from_local_storage():
    if not st.session_state.get("token"):
        result = streamlit_js_eval(js_expressions="localStorage.getItem('access_token')", key="get_token")
        if result and result != "null":
            st.session_state.token = result
            st.session_state.is_logged_in = True