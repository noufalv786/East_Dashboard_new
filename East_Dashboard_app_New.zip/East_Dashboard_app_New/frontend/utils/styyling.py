# utils/styling.py

import streamlit as st

def inject_custom_css():
    st.markdown("""
        <style>
        /* Hide Streamlit's default page selector */
        [data-testid="stSidebarNav"] {
            display: none;
        }

        /* Optional: Hide page selector dropdown in mobile view */
        header[data-testid="stHeader"] {
            z-index: -1;
        }
        </style>
    """, unsafe_allow_html=True)
