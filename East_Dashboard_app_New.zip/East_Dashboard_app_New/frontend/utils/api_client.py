import requests

API_BASE = "http://127.0.0.1:8001"

def create_meeting_api(meeting_data: dict):
    response = requests.post(f"{API_BASE}/meetings/create", json=meeting_data)
    return response
#for fetch meeting lists
def get_meetings_api(user_id):
    response=requests.get(f"{API_BASE}/meetings/",params={"user_id": user_id})
    response.raise_for_status()
    return response.json()
#save minutes
def create_minutes_api(meeting_data: dict):
    response = requests.post(f"{API_BASE}/minutes/create", json=meeting_data)
    return response
def read_minutes_by_meeting_api(meeting_id: int):
    response = requests.get(f"{API_BASE}/minutes/meeting/{meeting_id}")
    response.raise_for_status()
    return response.json()

def read_minutes_api(minutes_id: int):
    response = requests.get(f"{API_BASE}/minutes/{minutes_id}")
    response.raise_for_status() 
    return response.json()

def update_minutes_api(minutes_id: int, minutes_data: dict):
    response = requests.put(f"{API_BASE}/minutes/{minutes_id}", json=minutes_data)
    return response

#save minutes