import streamlit as st
import requests
from utils.sidebar import render_sidebar
from utils.styyling import inject_custom_css
st.set_page_config(page_title="Smart MoM", layout="wide")
render_sidebar()
inject_custom_css()
API_URL = "http://localhost:8001"

if not st.session_state.get("token"):
    st.warning("🔐 Please login from the main page.")
    st.stop()

st.title("📁 Upload Minutes of Meeting")

uploaded_file = st.file_uploader("Upload MoM file", type=["txt", "wav", "mp3", "png", "jpg"])

if uploaded_file:
    with st.spinner("Processing..."):
        try:
            filename = uploaded_file.name
            file_bytes = uploaded_file.getvalue()
            res = requests.post(
                f"{API_URL}/process_mom",
                files={"file": (filename, file_bytes)},
                headers={"Authorization": f"Bearer {st.session_state['token']}"}
            )

            if res.status_code == 200:
                data = res.json()
                st.success("✅ Processed Successfully!")
                st.subheader("🗣 Transcript")
                st.write(data.get("transcript", ""))
                st.subheader("🧠 Summary")
                st.write(data.get("summary", ""))
                if "action_items" in data:
                    st.subheader("✅ Action Items")
                    st.write(data["action_items"])
            else:
                st.error(f"Error: {res.status_code}, {res.text}")
        except Exception as e:
            st.error(f"Exception: {str(e)}")
