import streamlit as st

if not st.session_state.get("token"):
    st.warning("🔐 Please login from the main page.")
    st.stop()

st.title("⚙️ Settings")
st.write("Update your preferences here.")
