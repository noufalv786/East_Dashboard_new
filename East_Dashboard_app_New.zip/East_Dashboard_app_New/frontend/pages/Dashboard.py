import streamlit as st

if not st.session_state.get("token"):
    st.warning("🔐 Please login from the main page.")
    st.stop()

st.title("📊 Dashboard")
st.write("Welcome to the AI-powered Smart MoM Dashboard.")
