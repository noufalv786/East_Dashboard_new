import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from datetime import datetime
from st_aggrid import AgGrid, GridOptionsBuilder
from utils.components import render_top_header
from utils.sidebar import render_sidebar
from utils.session import restore_token_from_local_storage
from utils.api_client import create_meeting_api, get_meetings_api,create_minutes_api,read_minutes_by_meeting_api,update_minutes_api
from utils.auth import require_login
from utils.styyling import inject_custom_css
from streamlit_quill import st_quill  # <-- Add this import at the top
import re
from st_aggrid import GridUpdateMode
import io
from docx import Document
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
st.set_page_config("Smart MoM Report", layout="wide")

restore_token_from_local_storage()
require_login()
render_sidebar()
render_top_header()
inject_custom_css()

# Load meetings from API
if "meetings" not in st.session_state:
    try:
        user_id = 1  # Replace with dynamic user ID
        meetings_data = get_meetings_api(user_id)
        st.session_state.meetings = [
            {
                "id": m["id"],
                "Title": m["title"],
                "Date": m["date"],
                "Time": m["time"],
                "Location": m["location"],
                "Agendas": "\n".join(m["agendas"]),
                "Attendees": ", ".join(m["attendees"]),
                "Meeting Org": m.get("meeting_org", ""),
                "Meeting Type": m.get("meeting_type", ""),
                "Google Meet": m.get("google_meet_link", "")
            }
            for m in meetings_data
        ]
    except Exception as e:
        st.error(f"Failed to fetch meetings: {e}")

# Header and controls
with st.container():
    col1, col2, col3 = st.columns([9, 1.5, 1.5])
    with col1:
        st.markdown("### 🧾 Interactive Meeting Table")
    with col2:
        df = pd.DataFrame(st.session_state.meetings)
        st.download_button("💾 CSV", data=df.to_csv(index=False).encode("utf-8-sig"),
                           file_name="meetings.csv", use_container_width=True)
    with col3:
        with st.popover("➕ Add Meeting"):
            title = st.text_input("Meeting Title", key="title_input")
            date = st.date_input("Date", value=datetime.today(), key="date_input")
            time = st.text_input("Time (e.g. 2:00 PM)", key="time_input")
            location = st.text_input("Location", key="location_input")
            meeting_org = st.selectbox(
                "Meeting Organization",
                [
                    "Sankdana Center",
                    "Finance Cluster",
                    "Wisdom Cluster", 
                    "Kalallayam Cluster",
                    "Media Cluster",
                    "Sankhadana Cluster"
                ],
                key="meeting_org_input"
            )
            meeting_type = st.selectbox(
                "Meeting Type",
                [
                    "general",
                    "EB Meeting",
                    "Centrum Meeting",
                    "Cluster Meeting", 
                    "One-to-One Meeting",
                  
                ],
                key="meeting_type_input"
            )
            agendas_raw = st.text_area("Agendas (one per line)", key="agenda_input")
            attendees_input = st.text_area("Attendees Emails (comma-separated)")
            if st.button("Add", key="add_button"):
                agendas = [a.strip() for a in agendas_raw.split("\n") if a.strip()]
                attendees = [email.strip() for email in attendees_input.split(",") if email.strip()]
                payload = {
                    "title": title,
                    "date": date.isoformat(),
                    "time": time,
                    "location": location,
                    "agendas": agendas,
                    "meeting_org":meeting_org,
                    "meeting_type":meeting_type,
                    "attendees": attendees,
                    "user_id": 1
                }
                response = create_meeting_api(payload)
                if response.status_code == 200:
                    data = response.json()
                    st.success(f"✅ Meeting created! [Google Meet]({data['google_meet_link']})")
                    st.session_state.meetings.append({
                        "Title": title,
                        "Date": str(date),
                        "Time": time,
                        "Location": location,
                        "Meeting Org":meeting_org,
                         "Meeting Type":meeting_type,
                        "Agendas": "\n".join(agendas),
                        "Attendees": ", ".join(attendees),
                        "Google Meet": data.get("google_meet_link", "")
                    })
                    st.rerun()
                else:
                    st.error(f"❌ Failed to create meeting: {response.text}")

# Setup AgGrid
df = pd.DataFrame(st.session_state.meetings)
# Handle empty DataFrame
if df.empty:
    st.info("No meetings have been added yet. Create a new meeting using the form above.")
    st.stop()

gb = GridOptionsBuilder.from_dataframe(df)
gb.configure_selection(selection_mode="single", use_checkbox=True)
gb.configure_grid_options(domLayout='autoHeight', autoHeight=True)
grid_options = gb.build()

grid_response = AgGrid(
    df,
    gridOptions=grid_options,
  
    update_mode=GridUpdateMode.SELECTION_CHANGED,
    fit_columns_on_grid_load=True,
    theme="balham"
)

selected = pd.DataFrame(grid_response['selected_rows'])

# Manage modal visibility and data
if 'show_modal' not in st.session_state:
    st.session_state.show_modal = False
if 'selected_row' not in st.session_state:
    st.session_state.selected_row = None

# Toggle modal when a new row is selected
if not selected.empty:
    selected_dict = selected.iloc[0].to_dict()
    if st.session_state.selected_row != selected_dict:
        st.session_state.selected_row = selected_dict
        st.session_state.show_modal = True

# Render modal
if st.session_state.show_modal and st.session_state.selected_row is not None:
    row = st.session_state.selected_row
     # Dummy attendance summary for the chart (replace with real data later)
    attended = 7
    missed = 3

    # CSS styling
    st.markdown("""
    <style>
    .shadow-container {
        background-color: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1), 
                    0 2px 4px rgba(0, 0, 0, 0.06);
        margin-bottom: 20px;
    }
    .shadow-title {
        margin-bottom: 1rem;
    }
    </style>
    """, unsafe_allow_html=True)
    with st.container():
        st.markdown("<div class='shadow-container'>", unsafe_allow_html=True)
        col_left, col_right = st.columns([2, 1])

        # --- Left Column: Meeting Details ---
        with col_left:
            agendas_html = row['Agendas'].replace('\n', '<br>') if row['Agendas'] else "Not specified"
            attendees_html = row['Attendees'] if row['Attendees'] else "No attendees listed."
            meet_link_html = f'<a href="{row["Google Meet"]}" target="_blank">{row["Google Meet"]}</a>' if row["Google Meet"] else "No link available"

            st.markdown(f"""
            <div class='shadow-title'><h3>📋 {row['Title']}</h3></div>
            <p><strong>Meeting Source:</strong> {row['Meeting Org']}</p>
             <p><strong>Meeting Type:</strong> {row['Meeting Type']}</p>
            <p><strong>Date:</strong> {row['Date']}</p>
            <p><strong>Time:</strong> {row['Time']}</p>
            
            <p><strong>Location:</strong> {row['Location']}</p>
            <p><strong>Agendas:</strong><br>{agendas_html}</p>
            <p><strong>Attendees:</strong><br>{attendees_html}</p>
            <p><strong>Google Meet:</strong><br>{meet_link_html}</p>
            """, unsafe_allow_html=True)

        # --- Right Column: Attendance Pie Chart ---
        with col_right:
            st.subheader("🧑‍🤝‍🧑 Attendance Summary")

            fig = go.Figure(data=[go.Pie(
                labels=['Attended', 'Missed'],
                values=[attended, missed],
                hole=0.4,
                marker=dict(colors=['#34a853', '#ea4335']),
                textinfo='label+percent'
            )])
            fig.update_layout(margin=dict(t=10, b=10, l=10, r=10), height=300)
            st.plotly_chart(fig, use_container_width=True)

    st.markdown("</div>", unsafe_allow_html=True)
   
    # Action buttons
    btn_cols = st.columns(4)
    with btn_cols[0]:
        if st.button("❌ Cancel", key="cancel_btn"):
            st.session_state.show_modal = False
            st.rerun()
    with btn_cols[1]:
        if st.button("📤 Share", key="share_btn"):
            st.info("Share functionality coming soon...")
    with btn_cols[2]:
        if st.button("✏️ Edit", key="edit_btn"):
            st.info("Edit functionality coming soon...")
    with btn_cols[3]:
        if st.button("🗑️ Delete", key="delete_btn"):
            st.session_state.meetings = [
                m for m in st.session_state.meetings if m["Title"] != row["Title"]
            ]
            st.success("Meeting deleted.")
            st.session_state.show_modal = False
            st.rerun()

    # Tabs
    tab1, tab2 = st.tabs(["Attendance", "Minutes Document"])

    with tab1:
        st.header("Attendance")
        st.write("Attendance management coming soon.")

    with tab2:
        st.subheader("📝 Minutes Document")

      # Tab selection state
    tabs = {
        "Write": "📝 Write Minutes",
        "Screenshot": "🖼️ Screenshot",
        "Audio": "🎙️ Audio",
        "Download": "📥 Download"
    }
    tab_keys = list(tabs.keys())

    # Display tab menu
    selected_tab = st.radio(
        "Choose Action",
        tab_keys,
        format_func=lambda x: tabs[x],
        horizontal=True
    )

    st.markdown("""
    <style>
    /* Beautify the radio tabs */
    section[data-testid="stRadio"] > div {
        flex-direction: row !important;
        justify-content: space-around;
        gap: 1rem;
    }

    section[data-testid="stRadio"] label {
        background-color: #f3f3f3;
        padding: 1rem;
        border-radius: 1rem;
        cursor: pointer;
        text-align: center;
        transition: all 0.3s ease;
        box-shadow: 0 1px 4px rgba(0,0,0,0.1);
        font-weight: 600;
    }

    section[data-testid="stRadio"] label:hover {
        background-color: #e0e0e0;
        transform: translateY(-2px);
    }

    section[data-testid="stRadio"] label[data-selected="true"] {
        background-color: #d0ebff;
        color: #000;
    }
    </style>
    """, unsafe_allow_html=True)
    # Add custom styles once
    st.markdown("""
    <style>
    .header-with-button {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 0.5rem;
    }
    .save-icon-button > button {
        background-color: #1E90FF !important;
        color: white !important;
        border: none !important;
        padding: 0.3rem 0.6rem; 
        font-size: 0.9rem;
        border-radius: 6px;
        width: auto;
    }
    </style>
    """, unsafe_allow_html=True)
    # --- Tab Content Logic ---
    if selected_tab == "Write":
      # Render header and button side-by-side
        
        col_h1, col_h2,col_h3 = st.columns([8,2,1])
        with col_h1:

            st.markdown('<div class="header-with-icon">', unsafe_allow_html=True)
            st.subheader("✍️ Write Your Meeting Minutes")
            st.markdown('</div>', unsafe_allow_html=True)
        with col_h2:
            try:
                meeting_data = st.session_state.get("selected_row")
                if meeting_data:
                    existing_minutes = read_minutes_by_meeting_api(meeting_data.get("id", 1))
                    if existing_minutes:
                        minutes_content = existing_minutes[0]["minutes_content"]
                        st.markdown('<div style="display: flex; gap: 10px;">', unsafe_allow_html=True)

                        # PDF Download Button
                        if st.button("📄 PDF", key="download_pdf"):
                            pdf_buffer = io.BytesIO()
                            c = canvas.Canvas(pdf_buffer, pagesize=letter)
                            c.drawString(100, 750, "Meeting Minutes")
                            y = 730
                            for line in minutes_content.split('\n'):
                                if y < 50:
                                    c.showPage()
                                    y = 750
                                c.drawString(100, y, line)
                                y -= 15
                            c.save()
                            pdf_buffer.seek(0)
                            st.download_button(
                                label="Download PDF",
                                data=pdf_buffer,
                                file_name="meeting_minutes.pdf",
                                mime="application/pdf"
                            )

                        # Word Download Button
                        if st.button("📝 Word", key="download_word"):
                            try:
                                doc = Document()
                                doc.add_heading('Meeting Minutes', level=1)
                                # Optional metadata
                                title = meeting_data.get("Title", "N/A")
                                date = meeting_data.get("Date", "N/A")
                                doc.add_paragraph(f"Meeting: {title}")
                                doc.add_paragraph(f"Date: {date}")
                                doc.add_paragraph("")  # spacing
                                # Content
                                doc.add_paragraph(minutes_content)

                                doc_buffer = io.BytesIO()
                                doc.save(doc_buffer)
                                doc_buffer.seek(0)

                                st.download_button(
                                    label="Download Word",
                                    data=doc_buffer,
                                    file_name="meeting_minutes.docx",
                                    mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                )
                            except Exception as err:
                                st.error(f"Failed to generate Word document: {err}")

                            st.markdown('</div>', unsafe_allow_html=True)

            except Exception as e:
                st.error(f"Error checking minutes: {e}")
        with col_h3:
            st.markdown('<div class="save-icon-button">', unsafe_allow_html=True)
            if st.button("💾 Save", key="icon_save_btn"):  # Only icon, no text
                    # Get the selected meeting data
                    meeting_data = st.session_state.selected_row
                    # Extract meeting ID from title since it's not in selected row
                    if not meeting_data:
                        st.error("Please select a meeting first")
                        st.rerun()
                    # Check if username exists in session state
                    if not st.session_state.get("username"):
                        st.error("⚠️ Please log in first")
                        st.rerun()
            
                   # Validate input
                    if not st.session_state.get("rich_minutes"):
                        st.warning("⚠️ Write something before saving.")
                    else:
                        # Prepare payload for minutes API
                        minutes_payload = {
                            "meeting_id": meeting_data.get("id", 1),
                            "prepared_by": st.session_state.get("username"),  # 🔁 Replace with dynamic user email if available
                            "prepared_on": datetime.now().isoformat(),
                            "minutes_content": st.session_state["rich_minutes"],
                            "minutes_saved_url": None,
                            "archive": False
                        }
                        # Check if minutes already exist for this meeting
                        try:
                            # Get existing minutes for the meeting
                            existing_minutes = read_minutes_by_meeting_api(meeting_data.get("id", 1))
                            
                            if existing_minutes and len(existing_minutes) > 0:
                                # Update existing minutes
                                minutes_id = existing_minutes[0]["id"] # Get first minutes entry
                                response = update_minutes_api(minutes_id, minutes_payload)
                                if response.status_code == 200:
                                    st.success("✅ Minutes updated successfully!")
                                else:
                                    st.error(f"❌ Failed to update minutes: {response.text}")
                                st.rerun()
                        except Exception as e:
                            st.error(f"Error checking existing minutes: {str(e)}")
                            # Continue with create flow if check fails

                        # Call create minutes API
                        response = create_minutes_api(minutes_payload)
                        if response.status_code == 200:
                            st.success("✅ Minutes saved!")
                          
                            with st.expander("📄 Preview Minutes", expanded=True):
                                st.markdown(st.session_state["rich_minutes"], unsafe_allow_html=True)
                        else:
                            st.error(f"❌ Failed to save minutes: {response.text}")
                            st.markdown('</div>', unsafe_allow_html=True)
      

       # 1. Extract selected meeting
        meeting_data = st.session_state.get("selected_row", None)

        if meeting_data:
            meeting_id = meeting_data.get("id", None)

            # 2. Load existing minutes only if not already fetched
            if "rich_minutes" not in st.session_state:
                try:
                    existing_minutes = read_minutes_by_meeting_api(meeting_id)
                    if existing_minutes and len(existing_minutes) > 0:
                        st.session_state["rich_minutes"] = existing_minutes[0]["minutes_content"]
                    else:
                        st.session_state["rich_minutes"] = ""  # Empty editor
                except Exception as e:
                    st.error(f"Error loading existing minutes: {str(e)}")
                    st.session_state["rich_minutes"] = ""

            # 3. Render Rich Text Editor
            st.markdown("""
                <style>
                    .quill { width: 100% !important; }
                    .ql-container { width: 100% !important; }
                    .ql-editor { width: 100% !important; min-height: 300px; }
                </style>
            """, unsafe_allow_html=True)

            minutes_content = st_quill(value=st.session_state.get("rich_minutes", ""), key="rich_minutes", html=True)

        else:
            st.warning("⚠️ Please select a meeting to edit minutes.")

    elif selected_tab == "Screenshot":
        st.subheader("🖼️ Upload Screenshot")
        uploaded_image = st.file_uploader("Upload Image", type=["png", "jpg", "jpeg"])
        if uploaded_image:
            st.success("Screenshot uploaded. OCR coming soon...")

    elif selected_tab == "Audio":
        st.subheader("🎙️ Upload Audio")
        uploaded_audio = st.file_uploader("Upload Audio", type=["mp3", "wav", "m4a"])
        if uploaded_audio:
            st.success("Audio uploaded. Transcription coming soon...")

    elif selected_tab == "Download":
        st.subheader("📥 Download PDF")
        st.info("This will allow downloading the minutes as PDF soon.")
        if st.button("📄 Export to PDF"):
            st.warning("PDF export not implemented yet.")