import streamlit as st
import requests
from datetime import datetime
from utils.sidebar import render_sidebar
from utils.styyling import inject_custom_css
st.set_page_config(page_title="Smart MoM", layout="wide")
render_sidebar()
inject_custom_css()
st.title("📊 Dashboard")

with st.form("meeting_form"):
    title = st.text_input("Meeting Title")
    date = st.date_input("Meeting Date")
    time = st.time_input("Meeting Time")
    location = st.text_input("Location")
    agendas = st.text_area("Agenda Points (one per line)").splitlines()
    meet_link = st.text_input("Optional Google Meet Link")
    attendees_input = st.text_area("Attendees (comma-separated emails)")
    
    attendees = [email.strip() for email in attendees_input.split(",") if email.strip()]
    
    submitted = st.form_submit_button("Create Meeting")

if submitted:
    datetime_str = f"{date}T{time}"
    iso_datetime = datetime.fromisoformat(datetime_str).isoformat()

    payload = {
        "title": title,
        "date": iso_datetime,
        "agendas": agendas,
        "location": location,
        "google_meet_link": meet_link if meet_link else None,
        "attendees": attendees
    }

    try:
        response = requests.post("http://localhost:8001/create_meeting", json=payload)
        if response.status_code == 200:
            st.success("✅ Meeting created and added to Google Calendar")
            st.write(f"[📅 View Meeting]({response.json().get('eventLink')})")
        else:
            st.error(f"❌ Error: {response.text}")
    except Exception as e:
        st.error(f"Request failed: {e}")
